package com.mphasis.event.Training;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainingApplicationTests {

	@Test
	void contextLoads() {
	}

}
