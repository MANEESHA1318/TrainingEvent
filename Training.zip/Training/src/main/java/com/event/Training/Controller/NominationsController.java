package com.event.Training.Controller;

public class NominationsController {

}
