package com.event.Training.Services;

public class NominationsDetailsService {

}
