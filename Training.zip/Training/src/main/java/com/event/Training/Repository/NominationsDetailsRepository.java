package com.event.Training.Repository;

public class NominationsDetailsRepository {

}
